﻿using System;

namespace Kata.ShoppingCart
{
    public class Checkout : ICheckout
    {
        public double GetTotal(string items)
        {
            throw new NotImplementedException();
        }
    }
}